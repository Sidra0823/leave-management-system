
# Mini Leave Management System (Backend)

A production-style Node.js + Express + MongoDB backend implementing a Mini Leave Management System with JWT auth, RBAC (employee/admin), validation, and Swagger API docs.

See README in the zip for setup steps.
